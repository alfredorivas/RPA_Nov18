This directory contains syntax highlighting files for many popular editors as contributed by users
of AutoIt.

If you find that one is out of date then please submit a correction :)
